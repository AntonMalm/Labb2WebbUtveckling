﻿using Labb2WebbTemplate.DataAccess.DTOs;
using Labb2WebbTemplate.DataAccess.Entities;

namespace Labb2WebbTemplate.API.Extensions;

public static class ProductEndpointsExtension
{
    public static IEndpointRouteBuilder ProductEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/products");

        group.MapGet("/", GetAllProducts);
        group.MapGet("/{productNumber}", GetProductByProductNumber);
        group.MapPost("/", AddProduct);
        group.MapPut("/{productNumber}", UpdateProduct);
        group.MapPut("/discontinued/{productNumber}", MarkProductAsDiscontinued);
        group.MapDelete("/{productNumber}", RemoveProduct);

        return app;
    }

    private static async Task<IResult> RemoveProduct(ProductRepository repo, int productNumber)
    {
        var prod = await repo.GetProductByProductNumber(productNumber);
        if (prod is null)
        {
            Results.NotFound();
        }
        await repo.RemoveProduct(productNumber);
        return Results.Ok();
    }

    private static async Task MarkProductAsDiscontinued(ProductRepository repo, int productNumber)
    {
        var prod = await repo.GetProductByProductNumber(productNumber);
        if (prod is null)
        {
            Results.NotFound();
        }
        await repo.MarkProductAsDiscontinued(productNumber);
    }

    private static async Task UpdateProduct(ProductRepository repo, int productNumber, Product newProduct)
    {
        var product = await repo.GetProductByProductNumber(productNumber);
        if (product is null)
        {
            Results.NotFound();
        }
        await repo.UpdateProduct(productNumber, newProduct);
    }

    private static async Task AddProduct(ProductRepository repo, Product product)
    {
        await repo.AddProduct(product);
    }

    private static async Task<IResult> GetProductByProductNumber(ProductRepository repo, int productNumber)
    {
        var product = await repo.GetProductByProductNumber(productNumber);
        if (product is null)
        {
            return Results.NotFound();
        }
        return Results.Ok(product);
    }

    private static async Task<IEnumerable<ProductDto>> GetAllProducts(ProductRepository repo)
    {
        return await repo.GetAllProducts();
    }

}