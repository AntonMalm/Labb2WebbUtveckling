﻿using Labb2WebbTemplate.DataAccess.DTOs;

namespace Labb2WebbTemplate.API.Extensions;

public static class OrderEndpointsExtensions
{
    public static IEndpointRouteBuilder OrderEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/orders");

        group.MapGet("/", GetAllOrders);
        group.MapPost("/", AddOrder);
        group.MapGet("/customer/{customerId}", GetOrdersFromCustomer);
        group.MapDelete("/{orderId}", DeleteOrder);

        return app;
    }

    private static async Task<IResult> DeleteOrder(OrderRepository repo, int orderId)
    {
        var order = await repo.GetOrderById(orderId);
        if (order is null)
        {
            return Results.NotFound();
        }
        await repo.RemoveOrder(orderId);
        return Results.Ok();
    }


    private static async Task<IEnumerable<OrderReadDto>> GetOrdersFromCustomer(OrderRepository orderRepo, int customerId)
    {
        if (await orderRepo.GetOrdersFromCustomer(customerId) is null)
        {
            return null;
        }
        return await orderRepo.GetOrdersFromCustomer(customerId);
    }

    private static async Task<IEnumerable<OrderReadDto>> GetAllOrders(OrderRepository repo)
    {
        return await repo.GetAllOrders();
    }

    private static async Task AddOrder(OrderRepository repo, OrderDto order)
    {
        await repo.AddOrder(order);
    }
}