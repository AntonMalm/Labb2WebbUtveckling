﻿using Labb2WebbTemplate.DataAccess.DTOs;
using Labb2WebbTemplate.DataAccess.Entities;
using Labb2WebbTemplate.DataAccess.Repositories;

namespace Labb2WebbTemplate.API.Extensions;

public static class CustomerEndpointsExtensions
{
    public static IEndpointRouteBuilder CustomerEndpoints(this IEndpointRouteBuilder app)
    {
        var group = app.MapGroup("/customers");

        group.MapGet("/", GetAllCustomers);
        group.MapGet("/{Email}", GetCustomerByEmail);
        group.MapGet("/id/{Id}", GetCustomerById);
        group.MapPost("/", AddCustomer);
        group.MapPut("/{Email}", UpdateCustomer);
        group.MapDelete("/{Email}", RemoveCustomer);

        return app;
    }

    private static async Task<IResult> GetCustomerById(CustomerRepository repo, int Id)
    {
        if (await repo.GetCustomerById(Id) is null)
        {
            return Results.NotFound();
        }
        return Results.Ok(await repo.GetCustomerById(Id));
    }

    private static async Task<IResult> UpdateCustomer(CustomerRepository repo, string Email, Customer newCustomerData)
    {
        var existingCustomer = await repo.GetCustomerByEmail(Email);
        if (existingCustomer is null)
        {
            return Results.NotFound();
        }

        await repo.UpdateCustomer(Email, newCustomerData);

        // Optionally, you can return some success message or updated data
        return Results.Ok("Customer updated successfully");
    }

    private static async Task<IResult> RemoveCustomer(CustomerRepository repo, string Email)
    {
        var customer = await repo.GetCustomerByEmail(Email);
        if (customer is null)
        {
            return Results.NotFound();
        }

        await repo.RemoveCustomer(Email);
        return Results.Ok();
    }

    private static async Task<IResult> GetCustomerByEmail(CustomerRepository repo, string Email)
    {
        if (await repo.GetCustomerByEmail(Email) is null)
        {
            return Results.NotFound();
        }
        return Results.Ok(await repo.GetCustomerByEmail(Email));
    }

    private static async Task<IEnumerable<GetCustomerDto>> GetAllCustomers(CustomerRepository repo)
    {
        return await repo.GetAllCustomers();
    }

    private static async Task<IResult> AddCustomer(CustomerRepository repo, Customer customer)
    {
        if (await repo.GetCustomerByEmail(customer.Email) != null)
        {
            return Results.BadRequest("Email already exists");
        }
        await repo.AddCustomer(customer);
        return Results.Ok();
    }

}