﻿using Labb2WebbTemplate.DataAccess.DTOs;
using Labb2WebbTemplate.DataAccess.Entities;
using Shared.Interfaces;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;

namespace Labb2WebbTemplate.Client.Services
{
    public class OrderService : IOrderRepository<Order>
    {
        private readonly HttpClient _httpClient;

        public OrderService(IHttpClientFactory factory)
        {
            _httpClient = factory.CreateClient("StoreApi");
        }

        public async Task<IEnumerable<OrderReadDto>> GetOrdersFromCustomer(int customerId)
        {
            if (customerId == 0)
            {
                throw new ArgumentException("Customer ID cannot be 0");
            }

            var response = await _httpClient.GetAsync($"orders/customer/{customerId}");

            if (!response.IsSuccessStatusCode)
            {
                return new List<OrderReadDto>();
            }

            var result = await response.Content.ReadFromJsonAsync<List<OrderReadDto>>();
            return result ?? new List<OrderReadDto>();
        }

        public async Task<IEnumerable<OrderReadDto>> GetAllOrders()
        {
            var response = await _httpClient.GetAsync("orders");

            if (!response.IsSuccessStatusCode)
            {
                return new List<OrderReadDto>();
            }

            var orders = await response.Content.ReadFromJsonAsync<List<OrderReadDto>>();
            var orderReadDtos = new List<OrderReadDto>();

            foreach (var order in orders)
            {
                var orderReadDto = new OrderReadDto
                {
                    Id = order.Id,
                    CustomerId = order.CustomerId, // Access customerId directly
                    OrderDate = order.OrderDate,
                    Products = order.Products?.Select(p => new ProductDto
                    {
                        ProductNumber = p.ProductNumber,
                        Name = p.Name,
                        Price = p.Price,
                        IsDiscontined = p.IsDiscontined

                    }).ToList() ?? new List<ProductDto>()
                };

                orderReadDtos.Add(orderReadDto);
            }

            return orderReadDtos;
        }


        public async Task AddOrder(OrderDto orderDto)
        {
            var response = await _httpClient.PostAsJsonAsync("orders", orderDto);

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception("Failed to add the order");
            }
        }

        public async Task RemoveOrder(int orderId)
        {
            var response = await _httpClient.DeleteAsync($"orders/{orderId}");

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception("Failed to remove the order");
            }
        }

        public async Task<Order> GetOrderById(int orderId)
        {
            var response = await _httpClient.GetAsync($"orders/{orderId}");

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }

            var result = await response.Content.ReadFromJsonAsync<Order>();
            return result;
        }
    }
}
