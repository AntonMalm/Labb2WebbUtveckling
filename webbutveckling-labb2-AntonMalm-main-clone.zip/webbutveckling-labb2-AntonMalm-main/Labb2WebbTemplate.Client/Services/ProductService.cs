﻿using Labb2WebbTemplate.DataAccess.DTOs;
using Labb2WebbTemplate.DataAccess.Entities;
using Shared.Interfaces;
using System.Text.Json;

namespace Labb2WebbTemplate.Client.Services;

public class ProductService : IProductRepository<Product>
{
    private readonly HttpClient _http;

    public ProductService(IHttpClientFactory factory)
    {
        _http = factory.CreateClient("StoreApi");
    }

    public async Task<List<ProductDto>> GetAllProducts()
    {
        var respone = await _http.GetAsync("products");
        if (!respone.IsSuccessStatusCode)
        {
            return new List<ProductDto>();
        }
        var result = await respone.Content.ReadFromJsonAsync<List<ProductDto>>();
        return result ?? new List<ProductDto>();
    }

    public async Task<ProductDto> GetProductByProductNumber(int productNumber)
    {
        var response = await _http.GetAsync($"products/{productNumber}");

        if (response.IsSuccessStatusCode)
        {
            var foundProduct = await response.Content.ReadFromJsonAsync<ProductDto>();

            return foundProduct;
        }
        return null;
    }



    public async Task AddProduct(Product product)
    {
        var response = await _http.PostAsJsonAsync("products", product);
        if (!response.IsSuccessStatusCode)
        {
            throw new Exception("Failed to add the product");
        }
    }

    public async Task UpdateProduct(int id, Product updatedProduct)
    {
        var response = await _http.PutAsJsonAsync($"products/{id}", updatedProduct);
        if (!response.IsSuccessStatusCode)
        {
            throw new Exception("Failed to update the product");
        }
    }
    public async Task RemoveProduct(int id)
    {
        var response = await _http.DeleteAsync($"products/{id}");
        if (!response.IsSuccessStatusCode)
        {
            throw new Exception("Failed to remove the product");
        }
    }

    public async Task MarkProductAsDiscontinued(int id)
    {
        var respone = await _http.PutAsJsonAsync<Product>($"products/discontinued/{id}", null);
        if (!respone.IsSuccessStatusCode)
        {
            throw new Exception("Failed to mark the product as discontinued");
        }
    }
}