﻿using Labb2WebbTemplate.DataAccess.DTOs;
using Shared.Interfaces;
using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using Labb2WebbTemplate.DataAccess.Entities;

namespace Labb2WebbTemplate.Client.Services
{
    public class CustomerService : ICustomerRepository<Customer>
    {
        private readonly HttpClient _httpClient;

        public CustomerService(IHttpClientFactory factory)
        {
            _httpClient = factory.CreateClient("StoreApi");
        }

        public async Task<List<GetCustomerDto>> GetAllCustomers()
        {
            var response = await _httpClient.GetAsync("customers");

            if (!response.IsSuccessStatusCode)
            {
                return new List<GetCustomerDto>();
            }

            var result = await response.Content.ReadFromJsonAsync<List<GetCustomerDto>>();
            return result ?? new List<GetCustomerDto>();
        }

        public async Task<GetCustomerDto> GetCustomerByEmail(string email)
        {
            var response = await _httpClient.GetAsync($"customers/{email}");

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }

            var result = await response.Content.ReadFromJsonAsync<GetCustomerDto>();
            return result;
        }


        public async Task AddCustomer(Customer customer)
        {
            var response = await _httpClient.PostAsJsonAsync("customers", customer);

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception("Failed to add the customer");
            }
        }
        public async Task UpdateCustomer(string email, Customer updatedCustomer)
        {
            var response = await _httpClient.PutAsJsonAsync($"customers/{email}", updatedCustomer);

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception("Failed to update the customer");
            }
        }

        public async Task RemoveCustomer(string email)
        {
            var response = await _httpClient.DeleteAsync($"customers/{email}");

            if (!response.IsSuccessStatusCode)
            {
                throw new Exception("Failed to remove the customer");
            }
        }
        public async Task<GetCustomerDto> GetCustomerById(int id)
        {
            var response = await _httpClient.GetAsync($"customers/id/{id}");

            if (!response.IsSuccessStatusCode)
            {
                return null;
            }

            var result = await response.Content.ReadFromJsonAsync<GetCustomerDto>();
            return result;
        }
    }
}