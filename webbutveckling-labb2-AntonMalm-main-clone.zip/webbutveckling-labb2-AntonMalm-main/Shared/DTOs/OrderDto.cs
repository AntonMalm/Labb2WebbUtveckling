﻿namespace Labb2WebbTemplate.DataAccess.DTOs;

public class OrderDto
{
    public int CustomerId { get; set; }
    public List<int> OrderProductIds { get; set; } = new List<int>();
}