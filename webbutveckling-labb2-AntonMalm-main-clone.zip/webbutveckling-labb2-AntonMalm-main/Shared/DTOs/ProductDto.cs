﻿using System.ComponentModel.DataAnnotations;

namespace Labb2WebbTemplate.DataAccess.DTOs;

public class ProductDto
{
    [Key]
    public int ProductNumber { get; set; }
    public string Name { get; set; }
    public double Price { get; set; }
    public bool IsDiscontined { get; set; }
}