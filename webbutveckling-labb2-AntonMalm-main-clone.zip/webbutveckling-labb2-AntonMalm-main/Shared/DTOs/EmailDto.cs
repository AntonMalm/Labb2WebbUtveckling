﻿namespace Labb2WebbTemplate.DataAccess.DTOs;

public class EmailDto
{
    public string Email { get; set; }
}