﻿namespace Labb2WebbTemplate.DataAccess.DTOs;

public class OrderReadDto
{
    public int Id { get; set; }
    public int CustomerId { get; set; }
    public DateTime OrderDate { get; set; }
    public List<ProductDto> Products { get; set; } = new List<ProductDto>();
}
