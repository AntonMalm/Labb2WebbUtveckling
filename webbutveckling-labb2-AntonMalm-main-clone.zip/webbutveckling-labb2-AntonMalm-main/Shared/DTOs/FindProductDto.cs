﻿namespace Labb2WebbTemplate.DataAccess.DTOs;

public class FindProductDto
{
    public int ProductNumber { get; set; }
}