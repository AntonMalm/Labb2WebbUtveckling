﻿using Labb2WebbTemplate.DataAccess.DTOs;
using Labb2WebbTemplate.DataAccess.Entities;

namespace Shared.Interfaces;

public interface IOrderRepository<T> where T : class
{
    Task<IEnumerable<OrderReadDto>> GetOrdersFromCustomer(int customerId);
    Task<IEnumerable<OrderReadDto>> GetAllOrders();
    Task AddOrder(OrderDto orderDto);
    Task RemoveOrder(int orderId);
    Task<Order> GetOrderById(int orderId);
}

