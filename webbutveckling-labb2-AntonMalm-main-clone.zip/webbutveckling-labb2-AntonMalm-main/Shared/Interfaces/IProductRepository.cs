﻿using Labb2WebbTemplate.DataAccess.DTOs;
using Labb2WebbTemplate.DataAccess.Entities;

namespace Shared.Interfaces;

public interface IProductRepository<T> where T : class
{
    Task<List<ProductDto>> GetAllProducts();
    Task<ProductDto> GetProductByProductNumber(int id);
    Task AddProduct(Product product);
    Task UpdateProduct(int id, Product updatedProduct);
    Task RemoveProduct(int id);
    Task MarkProductAsDiscontinued(int id);
}