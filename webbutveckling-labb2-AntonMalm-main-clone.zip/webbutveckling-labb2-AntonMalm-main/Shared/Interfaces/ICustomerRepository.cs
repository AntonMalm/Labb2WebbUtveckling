﻿using Labb2WebbTemplate.DataAccess.DTOs;
using Labb2WebbTemplate.DataAccess.Entities;

namespace Shared.Interfaces;

public interface ICustomerRepository<T> where T : class
{
    Task<List<GetCustomerDto>> GetAllCustomers();
    Task<GetCustomerDto> GetCustomerByEmail(string email);
    Task AddCustomer(T customer);
    Task UpdateCustomer(string email, T updatedCustomer);
    Task RemoveCustomer(string email);
    Task<GetCustomerDto> GetCustomerById(int customerId);
}
