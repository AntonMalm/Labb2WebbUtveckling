﻿using System.ComponentModel.DataAnnotations;

namespace Labb2WebbTemplate.DataAccess.Entities;

public class Product
{
    [Key]
    public int ProductNumber { get; set; }
    [Required]
    public string Name { get; set; }
    [Required]
    public string Description { get; set; }
    [Required]
    public double Price { get; set; }
    [Required]
    public string Category { get; set; }
    public bool IsDiscontined { get; set; }
    public virtual ICollection<Order> Orders { get; set; } = new List<Order>();

}