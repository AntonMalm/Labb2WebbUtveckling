﻿using System.ComponentModel.DataAnnotations;

namespace Labb2WebbTemplate.DataAccess.Entities;

public class Order
{
    public int Id { get; set; }
    [Required]
    public Customer Customer { get; set; }
    [Required]

    public DateTime OrderDate { get; set; }
    [Required]

    public List<Product> Products { get; set; } = new List<Product>();

}