# Labb 2 APIer

## Product Class

### ProductNumber int

### Name string

### Description string

### Price double

### ProductCategory string

### IsDiscontinued bool

### Orders virtual ICollection of Order 


## Customer Class

### Id int

### FirstName string

### LastName string

### Email string [EmailAddress]

### PhoneNumber string [Phone]

### Address string

### City string

### ZipCode string

### Orders virtual ICollection of Order


## Order class

### Id int

### Customer Customer

### OrderDate DateTime

### List(Product) Products


# Endoints
## Product

| Path                  | Method | Request       | Response    | ResponseCodes   |
|-----------------------|--------|---------------|-------------|-----------------|
| "/products"               | GET    | NONE          | Products[]       | 200             |
| "/products/{productnumber}"          | GET    | int ProductNumber        | Product         | 200, 404        |
| "/products"        | POST    | Product   | NONE       | 200       |
| "/products/{ProductNumber}"         | PUT    | int ProductNumber       |NONE       | 200, 404             |
| "/products/Discontinued/{ProductNumber}"         | PUT    | int ProductNumber       |NONE       | 200,  404           |
| "/products/{productnumber}"   | DELETE    | int int ProductNumber       | NONE    | 200, 404             |

## Customer

| Path                  | Method | Request       | Response    | ResponseCodes   |
|-----------------------|--------|---------------|-------------|-----------------|
| "/customers"               | GET    | NONE          | Customers[]       | 200             |
| "/customers/{Email}"          | GET    | string Email        | Customer         | 200, 404        |
| "/customers/{id}"          | GET    | int id        | Customer         | 200, 404        |
| "/customers"        | POST    | Customer   | NONE       | 200, 400        |
| "/customer/{Email}"         | PUT    | string Email       |NONE       | 200, 404        |
| "/customers/{Email}"          | DELETE    | string Email        | NONE         | 200, 404        |

## Order methods  

| Path                  | Method | Request       | Response    | ResponseCodes   |
|-----------------------|--------|---------------|-------------|-----------------|
| "/orders"               | GET    |NONE          | Orders[]       | 200|  
| "/orders/{customerId}"               | GET    |int customerId          | Orders[]       | 200|  
| "/orders"               | POST    |Order          | NONE       | 200|  
| "/orders{orderId}"             | DELETE    | int OrderId          | NONE       | 200, 404|  