﻿using Labb2WebbTemplate.DataAccess.Entities;
using Microsoft.EntityFrameworkCore;

namespace Labb2WebbTemplate.DataAccess;

public class StoreDbContext : DbContext
{
    public DbSet<Customer> Customers { get; set; }
    public DbSet<Product> Products { get; set; }
    public DbSet<Order> Orders { get; set; }

    public StoreDbContext(DbContextOptions options) : base(options)
    {
        Database.EnsureCreated();
    }
}