﻿using Labb2WebbTemplate.DataAccess;
using Labb2WebbTemplate.DataAccess.DTOs;
using Labb2WebbTemplate.DataAccess.Entities;
using Microsoft.EntityFrameworkCore;
using Shared.Interfaces;


public class ProductRepository : IProductRepository<ProductDto>
{
    private readonly StoreDbContext _context;

    public ProductRepository(StoreDbContext context) => _context = context;

        public async Task<List<ProductDto>> GetAllProducts()
        {
            return await _context.Products.Select(p => new ProductDto
            {
                ProductNumber = p.ProductNumber,
                Name = p.Name,
                Price = p.Price,
                IsDiscontined = p.IsDiscontined
            }).ToListAsync();
        }

    public async Task<ProductDto> GetProductByProductNumber(int productNumber)
    {
        var foundProduct = await _context.Products.FirstOrDefaultAsync(p => p.ProductNumber == productNumber);
        if (foundProduct is null)
        {
            return null;
        }
        return new ProductDto
        {
            ProductNumber = foundProduct.ProductNumber,
            Name = foundProduct.Name,
            Price = foundProduct.Price,
            IsDiscontined = foundProduct.IsDiscontined
        };
    }


    public async Task AddProduct(Product product)
        {
            await _context.Products.AddAsync(product);
            await _context.SaveChangesAsync();
        }

        public async Task UpdateProduct(int productNumber, Product newProductData)
        {
            var existingProduct = await _context.Products.FirstOrDefaultAsync(p => p.ProductNumber == productNumber);
            if (existingProduct is null)
            {
                throw new ArgumentException("Product does not exist");
            }

            existingProduct.Name = newProductData.Name;
            existingProduct.Description = newProductData.Description;
            existingProduct.Price = newProductData.Price;
            existingProduct.Category = newProductData.Category;
            existingProduct.IsDiscontined = newProductData.IsDiscontined;

            await _context.SaveChangesAsync();
        }

        public async Task RemoveProduct(int productNumber)
        {
            var product = await _context.Products.FirstOrDefaultAsync(p => p.ProductNumber == productNumber);
            if (product != null)
            {
                _context.Products.Remove(product);
                await _context.SaveChangesAsync();
            }
        }

        public async Task MarkProductAsDiscontinued(int productNumber)
        {
            var product = await _context.Products.FirstOrDefaultAsync(p => p.ProductNumber == productNumber);
            if (product != null)
            {
                product.IsDiscontined = true;
                await _context.SaveChangesAsync();
            }
        }
    }


