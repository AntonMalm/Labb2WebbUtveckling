﻿using Labb2WebbTemplate.DataAccess.DTOs;
using Labb2WebbTemplate.DataAccess.Entities;
using Microsoft.EntityFrameworkCore;
using Shared.Interfaces;

namespace Labb2WebbTemplate.DataAccess.Repositories;

public class CustomerRepository : ICustomerRepository<Customer>
{

    private readonly StoreDbContext _context;

public CustomerRepository(StoreDbContext context)
{
    _context = context;
}

public async Task<List<GetCustomerDto>> GetAllCustomers()
{
    return await _context.Customers.Select(c => new GetCustomerDto
    {
        Id = c.Id,
        FirstName = c.FirstName,
        LastName = c.LastName,
        Email = c.Email,
        City = c.City
    }).ToListAsync();
}

public async Task<GetCustomerDto> GetCustomerByEmail(string email)
{
    var foundCustomer = await _context.Customers.FirstOrDefaultAsync(c => c.Email == email);
    if (foundCustomer is null)
    {
        return null;
    }
    return new GetCustomerDto
    {
        Id = foundCustomer.Id,
        FirstName = foundCustomer.FirstName,
        LastName = foundCustomer.LastName,
        Email = foundCustomer.Email,
        City = foundCustomer.City
    };
}

public async Task AddCustomer(Customer customer)
    {
        await _context.Customers.AddAsync(customer);
        await _context.SaveChangesAsync();
    }

public async Task UpdateCustomer(string Email, Customer newCustomerData)
{
    var existingCustomer = await _context.Customers.FirstOrDefaultAsync(c => c.Email == Email);
    if (existingCustomer is null)
    {
        throw new ArgumentException("Customer does not exist");
    }

    if (!existingCustomer.Email.Equals(newCustomerData.Email) &&
        _context.Customers.Any(c => c.Email == newCustomerData.Email))
    {
        throw new ArgumentException("Email already exists");
    }

    existingCustomer.FirstName = newCustomerData.FirstName;
    existingCustomer.LastName = newCustomerData.LastName;
    existingCustomer.PhoneNumber = newCustomerData.PhoneNumber;
    existingCustomer.Address = newCustomerData.Address;
    existingCustomer.City = newCustomerData.City;
    existingCustomer.ZipCode = newCustomerData.ZipCode;

    if (!existingCustomer.Email.Equals(newCustomerData.Email))
    {
        existingCustomer.Email = newCustomerData.Email;
    }

    await _context.SaveChangesAsync();
}



public async Task RemoveCustomer(string Email)
    {
        var customer = await _context.Customers.FirstOrDefaultAsync(c => c.Email == Email);
        if (customer != null)
        {
            _context.Customers.Remove(customer);
            await _context.SaveChangesAsync();
        }
        
    }

    public async Task<GetCustomerDto> GetCustomerById(int id)
    {
        var foundCustomer = await _context.Customers.FirstOrDefaultAsync(c => c.Id == id);
        if (foundCustomer is null)
        {
            return null;
        }
        return new GetCustomerDto
        {
            Id = foundCustomer.Id,
            FirstName = foundCustomer.FirstName,
            LastName = foundCustomer.LastName,
            Email = foundCustomer.Email,
            City = foundCustomer.City
        };
    }
}