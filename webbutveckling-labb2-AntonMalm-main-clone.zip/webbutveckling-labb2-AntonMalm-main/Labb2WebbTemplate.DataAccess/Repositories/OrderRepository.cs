﻿using Labb2WebbTemplate.DataAccess.Entities;
using Labb2WebbTemplate.DataAccess;
using Labb2WebbTemplate.DataAccess.DTOs;
using Microsoft.EntityFrameworkCore;
using Shared.Interfaces;

public class OrderRepository : IOrderRepository<Order>
{
    private readonly StoreDbContext _context;

    public OrderRepository(StoreDbContext context)
    {
        _context = context;
    }

    public async Task<IEnumerable<OrderReadDto>> GetOrdersFromCustomer(int customerId)
    {
        var orders = await _context.Orders
            .Include(o => o.Customer) 
            .Where(o => o.Customer != null && o.Customer.Id == customerId)
            .Include(o => o.Products)
            .ToListAsync();

        return orders.Select(o => new OrderReadDto
        {
            Id = o.Id,
            CustomerId = o.Customer?.Id ?? 0,
            OrderDate = o.OrderDate,
            Products = o.Products?.Select(p => new ProductDto
            {
                ProductNumber = p.ProductNumber,
                Name = p.Name,
                Price = p.Price
            }).ToList() ?? new List<ProductDto>()
        }).ToList();
    }

    public async Task<IEnumerable<OrderReadDto>> GetAllOrders()
    {
        var orders = await _context.Orders
            .Include(o => o.Customer)
            .Include(o => o.Products)
            .ToListAsync();

        return orders.Select(o => new OrderReadDto
        {
            Id = o.Id,
            CustomerId = o.Customer.Id,
            OrderDate = o.OrderDate,
            Products = o.Products.Select(p => new ProductDto
            {
                ProductNumber = p.ProductNumber,
                Name = p.Name,
                Price = p.Price,
                IsDiscontined = p.IsDiscontined
            }).ToList()
        });
    }


    public async Task AddOrder(OrderDto orderDto)   
    {
        var customer = await _context.Customers.FindAsync(orderDto.CustomerId);
        if (customer is null)
        {
            return;
        }

        var products = new List<Product>();
        foreach (var productId in orderDto.OrderProductIds)
        {
            var product = await _context.Products.FindAsync(productId);
            if (product != null)
            {
                products.Add(product);
            }
        }

        var order = new Order
        {
            Customer = customer,
            OrderDate = DateTime.Now,
            Products = products
        };

        foreach (var productId in orderDto.OrderProductIds)
        {
            var product = await _context.Products.FindAsync(productId);
            if (product != null)
            {
                _context.Products.Attach(product);
                order.Products.Add(product);
            }
        }


        await _context.Orders.AddAsync(order);
        await _context.SaveChangesAsync();
    }


    public async Task RemoveOrder(int orderId)
    {
        var order = _context.Orders.FindAsync(orderId);
        if (order == null)
        {
            return;
        }
        _context.Orders.Remove(await order);
        await _context.SaveChangesAsync();
        
    }

    public async Task<Order> GetOrderById(int orderId)
    {
        if (orderId == 0)
        {
            return null;
        }

        return await _context.Orders.FindAsync(orderId);
    }

}

