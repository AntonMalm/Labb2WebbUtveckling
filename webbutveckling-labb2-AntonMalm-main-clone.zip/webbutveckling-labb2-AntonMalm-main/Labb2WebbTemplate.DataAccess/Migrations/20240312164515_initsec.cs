﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Labb2WebbTemplate.DataAccess.Migrations
{
    /// <inheritdoc />
    public partial class initsec : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
